package com.capgemini.exception;

public class ProductException extends RuntimeException {
	
	public ProductException(String msg) {
		super(msg);
	}

}
